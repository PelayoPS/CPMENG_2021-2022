package gui;

import javax.swing.JLabel;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ButtonGroup;

public class RegistryForm<E> extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7457374234103303407L;
	private JPanel contentPane;
	private JButton btnCancel;
	private JButton btnNext;
	private JPanel panel;
	private JPanel PanelCustomerData;
	private JRadioButton rdbtnTakeAway;
	private JComboBox<?> comboBox;
	private JPasswordField Password1;
	private JPasswordField password2;
	private JRadioButton rdbtnOnSite;
	private JLabel IbCustomerName;
	private JLabel lbBithDate;
	private JLabel lbPassword;
	private JLabel lblNewLabel;
	private JTextField nameAndSurname;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	
	private ConfirmationDialog<?> confirmationDialog = null;
	
	private MainWindow mainWindow = null;
	
	
	/**
	 * Create the frame.
	 */
	public RegistryForm(MainWindow mainWindow) {
		
		this.mainWindow = mainWindow;
		
		setBackground(Color.WHITE);
		setTitle("Mc Donald's POS: Customer Information");
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 579, 433);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getBtnCancel());
		contentPane.add(getPanelCustomerData());
		contentPane.add(getBtnNext());
		contentPane.add(getPanel());
	}
	
	/**
	 * Closes the application if used
	 * @return
	 */
	private JButton getBtnCancel() {
		if (btnCancel == null) {
			btnCancel = new JButton("Cancel");
			buttonGroup.add(btnCancel);
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancel.setBackground(Color.RED);
			btnCancel.setBounds(414, 325, 89, 23);
		}
		return btnCancel;
	}
	
	/**
	 * Validates every field an continues
	 * @return
	 */
	private JButton getBtnNext() {
		if (btnNext == null) {
			btnNext = new JButton("Next\r\n");
			btnNext.setEnabled(true);
			btnNext.addActionListener(new ActionListener() {
				@SuppressWarnings("deprecation")
				public void actionPerformed(ActionEvent e) {
					boolean valid = true;
					if(getNameAndSurname().getText() == null || getNameAndSurname().getText().trim().isEmpty() ) {
						valid = false;
						JOptionPane.showMessageDialog(null, "Name and surname are invalid");
					}
					if(getPassword1().getText() == null || getPassword1().getText().trim().isEmpty()) {
						valid = false;
						JOptionPane.showMessageDialog(null, "first password is not valid");
					}
					if(getPassword2().getText() == null || getPassword2().getText().trim().isEmpty()) {
						valid = false;
						JOptionPane.showMessageDialog(null, "second password is not valid");
					}
					if(!getPassword1().getText().equals(getPassword2().getText())) {
						valid = false;
						JOptionPane.showMessageDialog(null, "please verify that the two passwords are the same");
					}
					if (valid == true) {
						JOptionPane.showMessageDialog(null, "your order is correct");
						showConfirmationDialog();
					}
						
					}
					
					
				}
			);
			btnNext.setBackground(Color.GREEN);
			btnNext.setForeground(Color.BLACK);
			btnNext.setBounds(314, 326, 85, 21);
		}
		return btnNext;
	}
	
	private void showConfirmationDialog() {
		confirmationDialog = new ConfirmationDialog<E>(this);
		confirmationDialog.setModal(true);
		confirmationDialog.setLocationRelativeTo(this);
		confirmationDialog.setVisible(true);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(new TitledBorder(new EtchedBorder(
					EtchedBorder.LOWERED, new Color(255, 255, 255), 
					new Color(160, 160, 160)), "Order", TitledBorder.LEADING,
					TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel.setBackground(new Color(255, 255, 255));
			panel.setBounds(35, 299, 190, 51);
			panel.setLayout(null);
			panel.add(getRdbtnTakeAway());
			panel.add(getRdbtnOnSite());
		}
		return panel;
	}
	
	private JRadioButton getRdbtnTakeAway() {
		if (rdbtnTakeAway == null) {
			rdbtnTakeAway = new JRadioButton("Take away");
			buttonGroup.add(rdbtnTakeAway);
			rdbtnTakeAway.setBackground(new Color(255, 255, 255));
			rdbtnTakeAway.setBounds(105, 12, 65, 23);
		}
		return rdbtnTakeAway;
	}
	
	private JRadioButton getRdbtnOnSite() {
		if (rdbtnOnSite == null) {
			rdbtnOnSite = new JRadioButton("On site");
			rdbtnOnSite.setSelected(true);
			buttonGroup.add(rdbtnOnSite);
			rdbtnOnSite.setBackground(new Color(255, 255, 255));
			rdbtnOnSite.setBounds(26, 12, 65, 23);
		}
		return rdbtnOnSite;
	}
	
	private JPanel getPanelCustomerData() {
		if (PanelCustomerData == null) {
			PanelCustomerData = new JPanel();
			PanelCustomerData.setBorder(new TitledBorder(null, "Customer Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			PanelCustomerData.setBackground(Color.WHITE);
			PanelCustomerData.setBounds(35, 52, 468, 236);
			PanelCustomerData.setLayout(null);
			PanelCustomerData.add(getIbCustomerName());
			PanelCustomerData.add(getPassword1());
			PanelCustomerData.add(getLbBithDate());
			PanelCustomerData.add(getComboBox());
			PanelCustomerData.add(getLbPassword());
			PanelCustomerData.add(getLbPasswordRepeated());
			PanelCustomerData.add(getPassword1());
			PanelCustomerData.add(getPassword2());
			PanelCustomerData.add(getNameAndSurname());
		}
		return PanelCustomerData;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private JComboBox getComboBox() {
		if (comboBox == null) {
			String[] years = new String[] {};
			List<String> year = new ArrayList<String>();
			comboBox = new JComboBox();
			comboBox.setBounds(162, 140, 133, 22);
			for (int i = 1910; i <= 2020;i++) {
				year.add(i+"");
			}
			years = year.toArray(years);
			comboBox.setModel(new DefaultComboBoxModel(years));
		}
		return comboBox;
	}
	private JPasswordField getPassword1() {
		if (Password1 == null) {
			Password1 = new JPasswordField();
			Password1.setBounds(162, 94, 227, 22);
			Password1.setColumns(10);
			Password1.setEchoChar('*');
		}
		return Password1;
	}
	private JLabel getIbCustomerName() {
		if (IbCustomerName == null) {
			IbCustomerName = new JLabel("Name and Surname:");
			IbCustomerName.setLabelFor(getNameAndSurname());
			IbCustomerName.setBounds(45, 51, 101, 13);
		}
		return IbCustomerName;
	}
	private JLabel getLbBithDate() {
		if (lbBithDate == null) {
			lbBithDate = new JLabel("Birth Day:");
			lbBithDate.setBounds(48, 145, 92, 13);
		}
		return lbBithDate;
	}
	private JLabel getLbPassword() {
		if (lbPassword == null) {
			lbPassword = new JLabel("Password:");
			lbPassword.setBounds(48, 99, 66, 13);
		}
		return lbPassword;
	}
	private JLabel getLbPasswordRepeated() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Repeat Password:");
			lblNewLabel.setBounds(45, 185, 83, 13);
		}
		return lblNewLabel;
	}
	private JPasswordField getPassword2() {
		if (password2 == null) {
			password2 = new JPasswordField();
			password2.setBounds(162, 181, 227, 20);
			password2.setColumns(10);
			password2.setEchoChar('*');
		}
		return password2;
	}
	private JTextField getNameAndSurname() {
		if (nameAndSurname == null) {
			nameAndSurname = new JTextField();
			nameAndSurname.setBounds(162, 47, 227, 20);
			nameAndSurname.setColumns(10);
		}
		return nameAndSurname;
	}

	public MainWindow getMainWindow() {
		return mainWindow;
	}
	
	public float getPrice() {
		return this.mainWindow.getPrice();
	}
}
