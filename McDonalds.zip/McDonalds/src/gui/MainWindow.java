package gui;

import javax.swing.JFrame;


import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SpinnerNumberModel;

import logic.FileUtil;
import logic.Menu;
import logic.Order;
import logic.Product;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class MainWindow extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected JFrame frmMcDonaldsPos;
	private JLabel lblMcDonalds;
	private JLabel lblProducts;
	private JComboBox<Product> productsComboBox;
	private JLabel lblMcTitle;
	private JSpinner units;
	private JButton btnAdd;
	private JTextField orderPrice;
	private JButton btnCancel;
	private JButton btnNext;
	private JLabel orderPriceLbl;
	private RegistryForm<?> customerInformationDialog;
	private Menu menu;
	private Order order;
	private JTextArea textAreaOrder;
	private JScrollPane scrollPane;

	private JLabel unitsLbl;

	/**
	 * Create the application.
	 * 
	 * @param menu
	 * @param order
	 */
	public MainWindow(Order order, Menu menu) {
		setOrder(order);
		setMenu(menu);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frmMcDonaldsPos = new JFrame();
		frmMcDonaldsPos.getContentPane().setBackground(Color.WHITE);
		frmMcDonaldsPos.setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindow.class.getResource("/img/logo.PNG")));
		frmMcDonaldsPos.setTitle("Mc Donald's POS");
		frmMcDonaldsPos.setBounds(100, 100, 950, 485);
		frmMcDonaldsPos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMcDonaldsPos.getContentPane().setLayout(null);
		frmMcDonaldsPos.getContentPane().add(getLblMcDonalds());
		frmMcDonaldsPos.getContentPane().add(getLblProducts());
		frmMcDonaldsPos.getContentPane().add(getProductsComboBox());
		frmMcDonaldsPos.getContentPane().add(getUnits());
		frmMcDonaldsPos.getContentPane().add(getLblMcTitle());
		frmMcDonaldsPos.getContentPane().add(getBtnAdd());
		frmMcDonaldsPos.getContentPane().add(getOrderPrice());
		frmMcDonaldsPos.getContentPane().add(getBtnCancel());
		frmMcDonaldsPos.getContentPane().add(getBtnNext());
		frmMcDonaldsPos.getContentPane().add(getOrderPriceLbl());
		frmMcDonaldsPos.getContentPane().add(getUnitsLbl());
		frmMcDonaldsPos.getContentPane().add(getScrollPane());
	}

	private JLabel getLblMcDonalds() {
		if (lblMcDonalds == null) {
			lblMcDonalds = new JLabel("");
			lblMcDonalds.setIcon(new ImageIcon(MainWindow.class.getResource("/img/logo.PNG")));
			lblMcDonalds.setBounds(141, 23, 231, 172);
		}
		return lblMcDonalds;
	}

	private JLabel getLblProducts() {
		if (lblProducts == null) {
			lblProducts = new JLabel("Products:");
			lblProducts.setDisplayedMnemonic('P');
			lblProducts.setToolTipText("");
			lblProducts.setLabelFor(getProductsComboBox());
			lblProducts.setFont(new Font("Arial", Font.BOLD, 15));
			lblProducts.setBounds(141, 201, 114, 24);
		}
		return lblProducts;
	}

	private JComboBox<Product> getProductsComboBox() {
		if (productsComboBox == null) {
			productsComboBox = new JComboBox<Product>();
			productsComboBox.setFont(new Font("Arial", Font.BOLD, 15));
			productsComboBox.setBounds(141, 236, 355, 35);
			productsComboBox.setModel(new DefaultComboBoxModel<Product>(menu.getProducts()));
			productsComboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					units.setValue(1);
				}
			});

		}
		return productsComboBox;
	}

	private JLabel getLblMcTitle() {
		if (lblMcTitle == null) {
			lblMcTitle = new JLabel("Mc Donald's");
			lblMcTitle.setFont(new Font("Arial Black", Font.PLAIN, 36));
			lblMcTitle.setBounds(381, 83, 292, 62);
		}
		return lblMcTitle;
	}

	private JSpinner getUnits() {
		if (units == null) {
			units = new JSpinner();
			units.setBackground(Color.WHITE);
			units.setModel(new SpinnerNumberModel(1, 0, 999, 1));
			units.setFont(new Font("Arial", Font.BOLD, 15));
			units.setBounds(506, 236, 52, 34);
		}
		return units;
	}

	private JButton getBtnAdd() {
		if (btnAdd == null) {
			btnAdd = new JButton("Add");
			btnAdd.setMnemonic('A');
			btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					Product selectedProduct = (Product) productsComboBox.getSelectedItem();
					Integer units = (Integer) getUnits().getValue();
					order.add(selectedProduct, units);

					orderPrice.setText(order.calcTotal() + "");
					btnNext.setEnabled(true);
					
					textAreaOrder.setEnabled(true);
					textAreaOrder.setText(order.toString());
				}
			});
			btnAdd.setBackground(Color.GREEN);
			btnAdd.setFont(new Font("Arial", Font.BOLD, 15));
			btnAdd.setBounds(584, 242, 89, 23);
		}
		return btnAdd;
	}

	private JTextField getOrderPrice() {
		if (orderPrice == null) {
			orderPrice = new JTextField();
			orderPrice.setFont(new Font("Arial", Font.BOLD, 15));
			orderPrice.setEditable(false);
			orderPrice.setBounds(506, 311, 105, 35);
			orderPrice.setColumns(10);
			orderPrice.setText("0");
		}
		return orderPrice;
	}

	private JButton getBtnCancel() {
		if (btnCancel == null) {
			btnCancel = new JButton("Cancel");
			btnCancel.setMnemonic('C');
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnCancel.setBackground(Color.RED);
			btnCancel.setFont(new Font("Arial", Font.BOLD, 15));
			btnCancel.setBounds(729, 396, 89, 23);
		}
		return btnCancel;
	}

	private JButton getBtnNext() {
		if (btnNext == null) {
			btnNext = new JButton("Next");
			btnNext.setMnemonic('N');
			btnNext.setEnabled(false);

			getRootPane().setDefaultButton(btnNext);

			btnNext.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showCustomerInformationDialog();
				}
			});
			btnNext.setBackground(Color.GREEN);
			btnNext.setForeground(Color.BLACK);
			btnNext.setFont(new Font("Arial", Font.BOLD, 15));
			btnNext.setBounds(616, 396, 89, 23);
		}
		return btnNext;
	}

	@SuppressWarnings("rawtypes")
	private void showCustomerInformationDialog() {
		customerInformationDialog = new RegistryForm(this);
		customerInformationDialog.setModal(true);
		customerInformationDialog.setLocationRelativeTo(this);
		customerInformationDialog.setVisible(true);
	}

	private JLabel getOrderPriceLbl() {
		if (orderPriceLbl == null) {
			orderPriceLbl = new JLabel("Order price:");
			orderPriceLbl.setFont(new Font("Arial", Font.BOLD, 15));
			orderPriceLbl.setBounds(506, 286, 105, 14);
		}
		return orderPriceLbl;
	}

	private JLabel getUnitsLbl() {
		if (unitsLbl == null) {
			unitsLbl = new JLabel("Units:");
			unitsLbl.setBackground(Color.WHITE);
			unitsLbl.setFont(new Font("Arial", Font.BOLD, 15));
			unitsLbl.setBounds(506, 203, 58, 20);
		}
		return unitsLbl;
	}
	
	private JTextArea getTextAreaOrder() {
		if (textAreaOrder == null) {
			textAreaOrder = new JTextArea();
			textAreaOrder.setEnabled(false);
			textAreaOrder.setEditable(false);
		}
		return textAreaOrder;
	}
	
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(634, 91, 278, 134);
			scrollPane.setViewportView(getTextAreaOrder());
		}
		return scrollPane;
	}
	
	

	public void setOrder(Order order) {
		this.order = order;

	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	/**
	 * @return the menu
	 */
	protected Menu getMenu() {
		return menu;
	}

	/**
	 * @return the order
	 */
	protected Order getOrder() {
		return order;
	}

	public float getPrice() {
		return order.calcTotal();
	}
}
