package gui;

import javax.swing.JDialog;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import logic.FileUtil;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConfirmationDialog<E> extends JDialog {

	private static final long serialVersionUID = -1637313464367853057L;

	private JLabel lblOK;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField textCode;
	private JButton btnFinish;

	private String orderCode = "";

	private RegistryForm<E> customerInformationDialog = null;
	private JTextField newPrice;
	private JLabel priceDiscount_lbl;

	/**
	 * Create the dialog.
	 */
	public ConfirmationDialog(RegistryForm<E> customerInformationDialog) {

		this.customerInformationDialog = customerInformationDialog;

		getContentPane().setBackground(Color.WHITE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ConfirmationDialog.class.getResource("/img/logo.PNG")));
		setTitle("Mc Donald's POS: Order confirmation");
		setBounds(100, 100, 575, 300);
		getContentPane().setLayout(null);
		getContentPane().add(getLblOK());
		getContentPane().add(getLblNewLabel());
		getContentPane().add(getLblNewLabel_1());
		getContentPane().add(getTextCode());
		getContentPane().add(getBtnFinish());

		this.orderCode = FileUtil.setFileName();
		getTextCode().setText(orderCode);
		
		
		// leave the code inside if outside to see it in the design view
		if (customerInformationDialog.getPrice() >= 50) {
			getContentPane().add(getNewPrice());
			getContentPane().add(getPriceDiscount_lbl());
		} else {
			getContentPane().add(getNewPrice());
			getContentPane().add(getPrice_lbl());
		}

	}

	private JLabel getLblOK() {
		if (lblOK == null) {
			lblOK = new JLabel("");
			lblOK.setIcon(new ImageIcon(ConfirmationDialog.class.getResource("/img/ok.png")));
			lblOK.setBounds(119, 67, 50, 76);
		}
		return lblOK;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Your order is being processed");
			lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 15));
			lblNewLabel.setBounds(201, 84, 211, 45);
		}
		return lblNewLabel;
	}

	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("Your order code is:");
			lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 15));
			lblNewLabel_1.setBounds(125, 142, 145, 45);
		}
		return lblNewLabel_1;
	}

	private JTextField getTextCode() {
		if (textCode == null) {
			textCode = new JTextField();
			textCode.setEditable(false);
			textCode.setBounds(280, 143, 132, 45);
			textCode.setColumns(10);
		}
		return textCode;
	}

	private JButton getBtnFinish() {
		if (btnFinish == null) {
			btnFinish = new JButton("Finish");
			btnFinish.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					customerInformationDialog.getMainWindow().getOrder().saveOrder(orderCode);
					System.exit(0);
				}
			});
			btnFinish.setFont(new Font("Arial", Font.PLAIN, 15));
			btnFinish.setBackground(Color.GREEN);
			btnFinish.setBounds(308, 214, 104, 36);
		}
		return btnFinish;
	}

	private JTextField getNewPrice() {
		if (newPrice == null) {
			newPrice = new JTextField();
			newPrice.setEditable(false);
			newPrice.setBounds(438, 23, 98, 33);
			newPrice.setColumns(10);
			newPrice.setText(customerInformationDialog.getMainWindow().getOrder().getPriceDiscount() + "");
		}
		return newPrice;
	}

	private JLabel getPriceDiscount_lbl() {
		if (priceDiscount_lbl == null) {
			priceDiscount_lbl = new JLabel(
					"You spent more than 50€ so a 10% discount is aplied to your order, the new price is: ");
			priceDiscount_lbl.setFont(new Font("Arial", Font.PLAIN, 11));
			priceDiscount_lbl.setBounds(10, 13, 431, 45);
		}
		return priceDiscount_lbl;
	}
	
	private JLabel getPrice_lbl() {
		if (priceDiscount_lbl == null) {
			priceDiscount_lbl = new JLabel(
					"The total order price is: ");
			priceDiscount_lbl.setFont(new Font("Arial", Font.PLAIN, 14));
			priceDiscount_lbl.setBounds(221, 17, 191, 45);
		}
		return priceDiscount_lbl;
	}


	
}
